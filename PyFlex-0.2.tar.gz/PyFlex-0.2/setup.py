from setuptools import setup, find_packages, dist
import os
import subprocess
import sys

dist.Distribution().fetch_build_eggs(['Cython>=0.15.1', 'numpy>=1.10'])

with open('PyFlex.egg-info/requires.txt') as f:
    requirements = f.readlines()

setup(
    name='PyFlex',
    version='0.2',
    packages=find_packages(),
    url='https://github.com/Alvaro-Ciudad/Pyflex',
    author='Álvaro Ciudad, Júlia Vilanta, Clara Suarez',
    author_email='pyflex@protonmail.com',
    description='PyFlex, your every day package for determining protein flexibility.',
    install_requires=requirements,
    python_requires='>=3.9',
    scripts=['main.py', 'blastscript/psiblast.py']
)
try:
    os.mkdir("outputs")
except FileExistsError:
    pass


def install(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

install("qt_material")
install("PyQt5")
