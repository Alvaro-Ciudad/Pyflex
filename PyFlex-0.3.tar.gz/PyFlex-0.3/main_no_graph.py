import os
import argparse
from pyflex import downloader, protein_treatment, GNMBuild, outputfun
import warnings
from Bio import BiopythonWarning
import shutil
import sys

def parserfunc():
    parser = argparse.ArgumentParser(
        description="This program does blablablabla")

    requiredNamed = parser.add_mutually_exclusive_group(required = True)

    requiredNamed.add_argument('-i', '--input',
                               dest="infile",
                               action="store",
                               default=None,
                               help="Input FASTA file/Uniprot Id")

    parser.add_argument('-o', '--output',
                        dest="outfile",
                        action="store",
                        default="output",
                        help="Output file")

    args = parser.parse_args()
    return args


def main():
    arg = parserfunc()
    path = os.path.dirname(os.path.abspath(__file__))

    if os.path.isfile(arg.infile):
        # Downloader
        id, seq = downloader.FASTA_iterator(arg.infile)
        job_id, ret_code = downloader.get_psiblast_prot(
            seq, "uniprotkb_swissprot", path)
        if ret_code != 0:
            shutil.rmtree('temp')
            raise ValueError("Problems with Psi-Blast, restart the program.")
        job = downloader.decode_job_id(job_id)
        best_candidate = protein_treatment.best_target_candidate(
            f"{path}/temp/{job}.preselected_ids.txt")
        id = downloader.alphafold_downloader(best_candidate, path)

        # GNMBuild
        scores = GNMBuild.obtain_MSFs(f"{path}/temp/{id}.pdb")

        job_id_pdb, ret_code = downloader.get_psiblast_prot(seq, "pdb", path)
        if ret_code != 0:
            shutil.rmtree('temp')
            raise ValueError("Problems with Psi-Blast, restart the program.")
        job_pdb = downloader.decode_job_id(job_id_pdb)

        # Protein treatment
        files = protein_treatment.list_of_pdbfiles_preprocessor(
            f"{path}/temp/{job_pdb}.ids.txt")
        os.chdir('./temp/')

        protein_treatment.pdb_download_files(files)
        homo = protein_treatment.split_files_by_chain(files)
        homo_object = protein_treatment.Homologues(homo)

        # Output
        scaled_scores = GNMBuild.B_factor_scaling(homo_object, scores)
        outputfun.write_pdb_CA(
            best_candidate.rstrip(), scores, "simulated", path, arg.outfile)
        outputfun.write_pdb_CA(
            best_candidate.rstrip(), scaled_scores, "scaled", path, arg.outfile)
        outputfun.plot_b_factors(scores, path, arg.outfile)
        os.chdir('../')
        sys.stdout.write(
            "Succesfully finished the job, output is in /outputs.\n")


    elif len(arg.infile) > 10:
        # Downloader
        job_id, ret_code = downloader.get_psiblast_prot(
            arg.infile, "uniprotkb_swissprot", path)
        if ret_code != 0:
            shutil.rmtree('temp')
            raise ValueError("Problems with Psi-Blast, restart the program.")
        job = downloader.decode_job_id(job_id)
        best_candidate = protein_treatment.best_target_candidate(
            f"{path}/temp/{job}.preselected_ids.txt")
        id = downloader.alphafold_downloader(best_candidate, path)

        # GNMBuild
        scores = GNMBuild.obtain_MSFs(f"{path}/temp/{id}.pdb")

        job_id_pdb, ret_code = downloader.get_psiblast_prot(
            arg.infile, "pdb", path)
        if ret_code != 0:
            shutil.rmtree('temp')
            raise ValueError("Problems with Psi-Blast, restart the program.")
        job_pdb = downloader.decode_job_id(job_id_pdb)

        # Protein treatment
        files = protein_treatment.list_of_pdbfiles_preprocessor(
            f"{path}/temp/{job_pdb}.ids.txt")
        os.chdir('./temp/')

        protein_treatment.pdb_download_files(files)
        homo = protein_treatment.split_files_by_chain(files)
        homo_object = protein_treatment.Homologues(homo)
        # Output
        scaled_scores = GNMBuild.B_factor_scaling(homo_object, scores)
        outputfun.write_pdb_CA(
            best_candidate.rstrip(), scores, "simulated", path, arg.outfile)
        outputfun.write_pdb_CA(
            best_candidate.rstrip(), scaled_scores, "scaled", path, arg.outfile)
        outputfun.plot_b_factors(scores, path, arg.outfile)
        os.chdir('../')
        sys.stdout.write(
            "Succesfully finished the job, output is in /outputs.\n")
    else:
        raise ValueError("Incorrect input, please use the path to the file or a\
        sequence in FASTA format.\n")


if __name__ == '__main__':
    try:
        os.mkdir("temp")
    except FileExistsError:
        shutil.rmtree('temp')
        os.mkdir("temp")
    warnings.simplefilter('ignore', BiopythonWarning)
    main()
    shutil.rmtree('temp')
