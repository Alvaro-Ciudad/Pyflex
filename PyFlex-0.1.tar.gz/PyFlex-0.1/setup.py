from setuptools import setup, find_packages

with open('requirements.txt') as f:
    requirements = f.readlines()

setup(
    name='PyFlex',
    version='0.1',
    packages=find_packages(),
    url='https://github.com/Alvaro-Ciudad/Pyflex',
    author='Álvaro Ciudad, Júlia Vilanta, Clara Suarez',
    author_email='pyflex@protonmail.com',
    description='PyFlex, your every day package for determining protein flexibility.',
    install_requires=requirements,
    python_requires='>=3.8',
    scripts=['main.py', 'blastscript/psiblast.py']
)
