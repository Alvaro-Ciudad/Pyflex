from setuptools import setup, find_packages, dist
import os
import subprocess
import sys

# Manually fetch the eggs of cython and numpy, easy install has problems with some
# of the c++ libraries.
dist.Distribution().fetch_build_eggs(['Cython>=0.15.1', 'numpy>=1.10'])

with open('PyFlex.egg-info/requires.txt') as f:
    requirements = f.readlines()

setup(
    name='PyFlex',
    version='0.4',
    packages=find_packages(),
    url='https://github.com/Alvaro-Ciudad/Pyflex',
    author='Álvaro Ciudad, Júlia Vilanta, Clara Suarez',
    author_email='pyflex@protonmail.com',
    description='PyFlex, your every day package for determining protein flexibility.',
    install_requires=requirements,
    python_requires='>=3.9',
    scripts=['main.py','main_no_graph.py', 'blastscript/psiblast.py','Q12851.fasta']
)
try:
    os.mkdir("outputs")
except FileExistsError:
    pass

#Pip installer, used to avoid some problems with installing dependencies of PyQt5.
def install(package):
    subprocess.check_call([sys.executable, "-m", "pip", "install", package])

install("qt_material")
install("PyQt5")
install("wheel")
